/** @type {const} */
const themeColors = {
  primary: { light: '#66704B', dark: '#AAB58A' },
  background: { light: '#F7F5EF', dark: '#1E211C' },
  surface: { light: '#FFFDF8', dark: '#282C25' },
  foreground: { light: '#252822', dark: '#F4F2EA' },
  muted: { light: '#74796C', dark: '#B4B9AB' },
  border: { light: '#E6E4DA', dark: '#41473B' },
  success: { light: '#66704B', dark: '#AAB58A' },
  warning: { light: '#B27A38', dark: '#E5B273' },
  error: { light: '#B85A50', dark: '#E48D82' },
};

module.exports = { themeColors };
