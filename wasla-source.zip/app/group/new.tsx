import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import { Alert, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

import { BubbleMark, COLORS, EmptyState, IconButton, Surface } from "@/components/wasla-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useWasla } from "@/hooks/use-wasla";

export default function NewGroupScreen() {
  const router = useRouter();
  const { addGroup } = useWasla();
  const [title, setTitle] = useState("");

  function createGroup() {
    if (title.trim().length < 2) {
      Alert.alert("اسم المجموعة", "اكتب اسمًا من حرفين على الأقل.");
      return;
    }
    const group = addGroup(title, []);
    if (group) router.replace({ pathname: "/chat/[id]", params: { id: group.id } });
  }

  return (
    <ScreenContainer safeAreaClassName="bg-[#F7F5EF]">
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 32 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}><IconButton name="arrow-forward" label="رجوع" onPress={() => router.back()} /><Text style={{ color: COLORS.ink, fontSize: 22, fontWeight: "900" }}>مجموعة جديدة</Text></View>
          <BubbleMark size={40} />
        </View>
        <Text style={{ color: COLORS.muted, fontSize: 14, lineHeight: 22, textAlign: "right", marginTop: 24 }}>المجموعات للرسائل والملفات فقط. أضف أعضاء من أجهزة وصلة التي تم اكتشافها وقبولها فعليًا.</Text>
        <Text style={{ color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right", marginTop: 24, marginBottom: 9 }}>اسم المجموعة</Text>
        <TextInput value={title} onChangeText={setTitle} placeholder="مثال: العائلة" placeholderTextColor="#9A9D92" style={{ height: 56, borderRadius: 17, backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.line, paddingHorizontal: 16, color: COLORS.ink, fontSize: 16, textAlign: "right" }} />

        <Text style={{ color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right", marginTop: 25, marginBottom: 9 }}>الأعضاء</Text>
        <Surface>
          <EmptyState icon="people-outline" title="لا يوجد أعضاء متاحون للاختيار" body="لا نضيف أجهزة افتراضية. سيظهر هنا كل جهاز يثبت تشغيل وصلة عليه بعد اتصال محلي حقيقي." />
        </Surface>

        <View style={{ marginTop: 15, padding: 14, borderRadius: 17, backgroundColor: COLORS.olivePale, flexDirection: "row-reverse", gap: 9, alignItems: "flex-start" }}>
          <Ionicons name="information-circle-outline" size={19} color={COLORS.olive} />
          <Text style={{ flex: 1, color: COLORS.olive, fontSize: 12, lineHeight: 19, textAlign: "right" }}>يمكن إنشاء المجموعة محليًا الآن، لكن الدعوات والرسائل لا تغادر هذا الجهاز قبل توفر أعضاء متصلين.</Text>
        </View>

        <TouchableOpacity onPress={createGroup} activeOpacity={0.8} style={{ height: 54, borderRadius: 17, backgroundColor: title.trim().length >= 2 ? COLORS.olive : "#D8DBD0", alignItems: "center", justifyContent: "center", marginTop: 24 }}><Text style={{ color: COLORS.white, fontSize: 15, fontWeight: "800" }}>إنشاء المجموعة</Text></TouchableOpacity>
        <Text style={{ color: COLORS.muted, fontSize: 12, textAlign: "center", marginTop: 12 }}>المضيف المحلي لا يغني عن اتصال الأعضاء.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}
