import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { useAudioRecorder, RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioPlayer } from "expo-audio";
import * as ImagePicker from "expo-image-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, Image, KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

import { BubbleMark, COLORS, IconButton, StatusPill } from "@/components/wasla-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useWasla } from "@/hooks/use-wasla";
import type { LocalMessage } from "@/lib/wasla/store";
import { formatTime } from "@/lib/wasla/store";

export default function ChatScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id: string }>();
  const threadId = Array.isArray(params.id) ? params.id[0] : params.id;
  const { state, addMessage, messagesFor } = useWasla();
  const [draft, setDraft] = useState("");
  const [recording, setRecording] = useState(false);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const conversation = state.conversations.find((item) => item.id === threadId);
  const messages = useMemo(() => messagesFor(threadId), [messagesFor, threadId]);

  async function sendText() {
    const text = draft.trim();
    if (!text) return;
    addMessage({ threadId, kind: "text", text });
    setDraft("");
  }

  async function chooseFile() {
    const result = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
    if (!result.canceled && result.assets[0]) {
      const file = result.assets[0];
      addMessage({ threadId, kind: "file", attachment: { uri: file.uri, name: file.name, mimeType: file.mimeType, size: file.size } });
    }
  }

  async function chooseImage() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("الأذونات", "نحتاج إذن الصور لاختيار مرفق من جهازك.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.85 });
    if (!result.canceled && result.assets[0]) {
      const image = result.assets[0];
      addMessage({ threadId, kind: "image", attachment: { uri: image.uri, name: image.fileName ?? "image.jpg", mimeType: image.mimeType, size: image.fileSize } });
    }
  }

  async function toggleRecording() {
    if (recording) {
      await recorder.stop();
      setRecording(false);
      if (recorder.uri) addMessage({ threadId, kind: "audio", attachment: { uri: recorder.uri, name: "voice-message.m4a", mimeType: "audio/m4a" } });
      return;
    }
    const permission = await requestRecordingPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("الميكروفون", "نحتاج إذن الميكروفون لتسجيل رسالة صوتية.");
      return;
    }
    await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
    await recorder.prepareToRecordAsync();
    recorder.record();
    setRecording(true);
  }

  if (!conversation) {
    return <ScreenContainer safeAreaClassName="bg-[#F7F5EF]"><View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}><Text style={{ color: COLORS.ink, fontSize: 18, fontWeight: "800", textAlign: "center" }}>المحادثة غير موجودة على هذا الجهاز</Text><TouchableOpacity onPress={() => router.back()} style={{ marginTop: 16 }}><Text style={{ color: COLORS.olive, fontWeight: "800" }}>رجوع</Text></TouchableOpacity></View></ScreenContainer>;
  }

  return (
    <ScreenContainer safeAreaClassName="bg-[#F7F5EF]" edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={8}>
        <View style={{ paddingHorizontal: 15, paddingTop: 10, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: COLORS.line, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", backgroundColor: COLORS.canvas }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}><IconButton name="arrow-forward" label="رجوع" onPress={() => router.back()} /><View style={{ width: 40, height: 40, borderRadius: 14, backgroundColor: conversation.kind === "group" ? COLORS.oliveSoft : "#ECEBE3", alignItems: "center", justifyContent: "center" }}><Ionicons name={conversation.kind === "group" ? "people-outline" : "person-outline"} size={20} color={COLORS.olive} /></View><View><Text style={{ color: COLORS.ink, fontSize: 16, fontWeight: "900", textAlign: "right" }}>{conversation.title}</Text><Text style={{ color: COLORS.muted, fontSize: 11, marginTop: 2, textAlign: "right" }}>{conversation.kind === "group" ? `${conversation.participantIds.length} أعضاء` : "محادثة فردية"}</Text></View></View>
          <BubbleMark size={38} />
        </View>

        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 18, flexGrow: 1 }} showsVerticalScrollIndicator={false}>
          <View style={{ alignItems: "center", marginBottom: 20 }}><StatusPill tone="quiet">محفوظ محليًا على هذا الجهاز</StatusPill><Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 19, textAlign: "center", marginTop: 9, maxWidth: 310 }}>لا يظهر تأكيد الإرسال حتى يثبت اتصال طرف آخر. الرسائل هنا تنتظر النقل ولا تُقدّم كرسائل مستلمة.</Text></View>
          {messages.length === 0 ? <View style={{ flex: 1, alignItems: "center", justifyContent: "center", minHeight: 260 }}><Ionicons name="chatbubble-ellipses-outline" size={34} color={COLORS.olive} /><Text style={{ color: COLORS.ink, fontSize: 16, fontWeight: "800", marginTop: 12 }}>ابدأ برسالة محلية</Text><Text style={{ color: COLORS.muted, fontSize: 13, marginTop: 6, textAlign: "center" }}>اكتب الآن، وستبقى الرسالة في قائمة الانتظار حتى يتوفر اتصال حقيقي.</Text></View> : messages.map((message) => <MessageBubble key={message.id} message={message} own={message.senderId === state.profile?.id} />)}
        </ScrollView>

        <View style={{ borderTopWidth: 1, borderTopColor: COLORS.line, paddingHorizontal: 12, paddingTop: 10, paddingBottom: Platform.OS === "web" ? 10 : 8, backgroundColor: COLORS.paper }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "flex-end", gap: 8 }}>
            <TouchableOpacity onPress={() => void toggleRecording()} activeOpacity={0.7} style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: recording ? "#F7EBDD" : COLORS.olivePale, alignItems: "center", justifyContent: "center" }}><Ionicons name={recording ? "stop" : "mic-outline"} size={19} color={recording ? COLORS.danger : COLORS.olive} /></TouchableOpacity>
            <TouchableOpacity onPress={() => void chooseFile()} activeOpacity={0.7} style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.olivePale, alignItems: "center", justifyContent: "center" }}><Ionicons name="attach-outline" size={20} color={COLORS.olive} /></TouchableOpacity>
            <TouchableOpacity onPress={() => void chooseImage()} activeOpacity={0.7} style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.olivePale, alignItems: "center", justifyContent: "center" }}><Ionicons name="image-outline" size={19} color={COLORS.olive} /></TouchableOpacity>
            <TextInput value={draft} onChangeText={setDraft} placeholder={recording ? "جارٍ التسجيل…" : "اكتب رسالة"} placeholderTextColor="#9A9D92" multiline maxLength={2000} style={{ flex: 1, minHeight: 42, maxHeight: 100, borderRadius: 15, backgroundColor: COLORS.canvas, color: COLORS.ink, fontSize: 15, paddingHorizontal: 14, paddingVertical: 10, textAlign: "right" }} />
            <TouchableOpacity onPress={() => void sendText()} activeOpacity={0.8} style={{ width: 44, height: 44, borderRadius: 15, backgroundColor: draft.trim() ? COLORS.olive : "#D8DBD0", alignItems: "center", justifyContent: "center" }}><Ionicons name="arrow-up" size={21} color={COLORS.white} /></TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function MessageBubble({ message, own }: { message: LocalMessage; own: boolean }) {
  return (
    <View style={{ alignItems: own ? "flex-start" : "flex-end", marginBottom: 10 }}>
      <View style={{ maxWidth: "86%", backgroundColor: own ? COLORS.olive : COLORS.paper, borderWidth: own ? 0 : 1, borderColor: COLORS.line, borderRadius: 19, borderBottomLeftRadius: own ? 6 : 19, borderBottomRightRadius: own ? 19 : 6, paddingHorizontal: 14, paddingVertical: 11 }}>
        {message.kind === "image" && message.attachment ? <Image source={{ uri: message.attachment.uri }} style={{ width: 210, height: 160, borderRadius: 12, marginBottom: message.text ? 8 : 0 }} resizeMode="cover" /> : null}
        {message.kind === "file" ? <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: message.text ? 8 : 0 }}><Ionicons name="document-text-outline" size={22} color={own ? COLORS.white : COLORS.olive} /><Text style={{ color: own ? COLORS.white : COLORS.ink, fontSize: 13, fontWeight: "700", flexShrink: 1 }}>{message.attachment?.name}</Text></View> : null}
        {message.kind === "audio" ? <AudioAttachment uri={message.attachment?.uri} own={own} /> : null}
        {message.text ? <Text style={{ color: own ? COLORS.white : COLORS.ink, fontSize: 15, lineHeight: 22, textAlign: "right" }}>{message.text}</Text> : null}
      </View>
      <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 5, marginTop: 4 }}><Text style={{ color: COLORS.muted, fontSize: 10 }}>{formatTime(message.createdAt)}</Text><Text style={{ color: COLORS.muted, fontSize: 10 }}>{message.status === "queued" ? "محفوظ محليًا" : message.status}</Text></View>
    </View>
  );
}

function AudioAttachment({ uri, own }: { uri?: string; own: boolean }) {
  const player = useAudioPlayer(uri ?? null);
  return <TouchableOpacity onPress={() => player.play()} activeOpacity={0.7} style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}><Ionicons name="play-circle-outline" size={26} color={own ? COLORS.white : COLORS.olive} /><Text style={{ color: own ? COLORS.white : COLORS.ink, fontSize: 13, fontWeight: "700" }}>تشغيل الرسالة الصوتية</Text></TouchableOpacity>;
}
