import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

import { BubbleMark, COLORS, EmptyState, IconButton, SectionTitle, StatusPill, Surface } from "@/components/wasla-ui";
import { useWasla } from "@/hooks/use-wasla";
import { formatTime, getConversationPreview } from "@/lib/wasla/store";
import { ScreenContainer } from "@/components/screen-container";

export default function HomeScreen() {
  const router = useRouter();
  const { state, hydrated, transport, isSaving, setProfileName, discover } = useWasla();
  const [nameDraft, setNameDraft] = useState("");
  const discoveryStarted = useRef(false);

  useEffect(() => {
    if (hydrated && state.profile && !discoveryStarted.current) {
      discoveryStarted.current = true;
      void discover("bluetooth");
    }
  }, [discover, hydrated, state.profile]);

  if (!hydrated) {
    return (
      <ScreenContainer safeAreaClassName="bg-[#F7F5EF]">
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={COLORS.olive} />
        </View>
      </ScreenContainer>
    );
  }

  if (!state.profile) {
    return (
      <ScreenContainer safeAreaClassName="bg-[#F7F5EF]">
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <View style={{ flex: 1, paddingHorizontal: 24, paddingTop: 68, justifyContent: "space-between", paddingBottom: 34 }}>
            <View>
              <BubbleMark size={58} />
              <Text style={{ color: COLORS.ink, fontSize: 34, lineHeight: 42, fontWeight: "900", marginTop: 28, textAlign: "right" }}>رسائلك،{"\n"}قريبة منك.</Text>
              <Text style={{ color: COLORS.muted, fontSize: 16, lineHeight: 26, marginTop: 18, textAlign: "right" }}>وصلة محادثة محلية هادئة. بلا حسابات، بلا سحابة، وبلا ضجيج.</Text>
            </View>
            <View>
              <Text style={{ color: COLORS.ink, fontSize: 14, fontWeight: "800", marginBottom: 9, textAlign: "right" }}>ما الاسم الذي سيظهر للأجهزة القريبة؟</Text>
              <TextInput value={nameDraft} onChangeText={setNameDraft} placeholder="اكتب اسمك" placeholderTextColor="#9A9D92" autoCapitalize="words" returnKeyType="done" style={{ backgroundColor: COLORS.paper, borderWidth: 1, borderColor: COLORS.line, borderRadius: 17, paddingHorizontal: 16, height: 56, color: COLORS.ink, fontSize: 16, textAlign: "right" }} />
              <TouchableOpacity disabled={nameDraft.trim().length < 2} onPress={() => setProfileName(nameDraft)} activeOpacity={0.8} style={{ height: 54, borderRadius: 17, marginTop: 12, alignItems: "center", justifyContent: "center", backgroundColor: nameDraft.trim().length >= 2 ? COLORS.olive : "#D8DBD0" }}>
                <Text style={{ color: COLORS.white, fontSize: 15, fontWeight: "800" }}>المتابعة</Text>
              </TouchableOpacity>
              <Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 19, textAlign: "center", marginTop: 14 }}>يبقى الاسم وسجل المحادثات على هذا الجهاز فقط.</Text>
            </View>
          </View>
        </KeyboardAvoidingView>
      </ScreenContainer>
    );
  }

  const statusTone = transport.state === "searching" ? "warn" : transport.state === "ready" ? "ok" : "quiet";
  const statusLabel = transport.state === "searching" ? "يبحث الآن" : transport.state === "ready" ? "متصل محليًا" : "غير متصل";

  return (
    <ScreenContainer safeAreaClassName="bg-[#F7F5EF]">
      <ScrollView contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 18, paddingBottom: 32 }} showsVerticalScrollIndicator={false}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <BubbleMark size={42} />
            <View>
              <Text style={{ color: COLORS.muted, fontSize: 12, textAlign: "right" }}>صباح الخير،</Text>
              <Text style={{ color: COLORS.ink, fontSize: 18, fontWeight: "900", textAlign: "right" }}>{state.profile.name}</Text>
            </View>
          </View>
          <IconButton name="settings-outline" label="الإعدادات" onPress={() => router.push("/settings")} />
        </View>

        <View style={{ marginTop: 26, flexDirection: "row-reverse", alignItems: "flex-end", justifyContent: "space-between" }}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: COLORS.ink, fontSize: 29, lineHeight: 35, fontWeight: "900", textAlign: "right" }}>قريبون منك.</Text>
            <Text style={{ color: COLORS.muted, fontSize: 14, lineHeight: 21, marginTop: 7, textAlign: "right" }}>ابدأ من هنا. لا نعرض إلا الأجهزة التي تثبت وجود وصلة عليها.</Text>
          </View>
          <TouchableOpacity onPress={() => router.push("/group/new")} activeOpacity={0.8} style={{ marginRight: 12, width: 56, height: 56, borderRadius: 19, backgroundColor: COLORS.olive, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="people-outline" size={23} color={COLORS.white} />
            <Ionicons name="add" size={12} color={COLORS.white} style={{ position: "absolute", bottom: 11, right: 11 }} />
          </TouchableOpacity>
        </View>

        <Surface style={{ marginTop: 20, padding: 15 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 9 }}>
              <View style={{ width: 37, height: 37, borderRadius: 13, backgroundColor: COLORS.olivePale, alignItems: "center", justifyContent: "center" }}><Ionicons name="bluetooth-outline" size={19} color={COLORS.olive} /></View>
              <View>
                <Text style={{ color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right" }}>الاتصال المحلي</Text>
                <Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right" }}>{transport.detail}</Text>
              </View>
            </View>
            <StatusPill tone={statusTone}>{statusLabel}</StatusPill>
          </View>
          <TouchableOpacity onPress={() => void discover("bluetooth")} activeOpacity={0.75} style={{ marginTop: 14, borderTopWidth: 1, borderTopColor: COLORS.line, paddingTop: 13, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <Ionicons name={transport.state === "searching" ? "radio-outline" : "refresh-outline"} size={16} color={COLORS.olive} />
            <Text style={{ color: COLORS.olive, fontSize: 13, fontWeight: "800" }}>{transport.state === "searching" ? "جارٍ البحث…" : "بدء البحث من جديد"}</Text>
          </TouchableOpacity>
        </Surface>

        <View style={{ marginTop: 28 }}>
          <SectionTitle title="الأجهزة القريبة" action="Wi‑Fi محلي" onAction={() => void discover("lan")} />
          <Surface>
            <EmptyState icon="radio-outline" title="لا توجد أجهزة مؤكدة بعد" body="لن نُظهر أسماء تجريبية. شغّل Native build مع وحدة النقل المحلي، وامنح الأذونات، ليظهر الجهاز عند تشغيل وصلة عليه." />
          </Surface>
        </View>

        <View style={{ marginTop: 28 }}>
          <SectionTitle title="محادثاتك" action={state.conversations.length ? "كلها" : undefined} />
          <Surface>
            {state.conversations.length === 0 ? <EmptyState icon="chatbubbles-outline" title="المكان هادئ هنا" body="عند اتصال جهاز موثوق ستظهر محادثتك هنا، وتبقى الرسائل محفوظة على جهازك." /> : [...state.conversations].sort((a, b) => b.updatedAt - a.updatedAt).map((conversation) => (
              <TouchableOpacity key={conversation.id} onPress={() => router.push({ pathname: "/chat/[id]", params: { id: conversation.id } })} activeOpacity={0.72} style={{ paddingHorizontal: 15, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: COLORS.line, flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 16, backgroundColor: conversation.kind === "group" ? COLORS.oliveSoft : "#ECEBE3", alignItems: "center", justifyContent: "center" }}><Ionicons name={conversation.kind === "group" ? "people-outline" : "person-outline"} size={20} color={COLORS.olive} /></View>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: COLORS.ink, fontSize: 15, fontWeight: "800" }}>{conversation.title}</Text><Text style={{ color: COLORS.muted, fontSize: 11 }}>{formatTime(conversation.updatedAt)}</Text></View>
                  <Text numberOfLines={1} style={{ color: COLORS.muted, fontSize: 13, marginTop: 5, textAlign: "right" }}>{getConversationPreview(conversation, state.messages)}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </Surface>
        </View>

        <View style={{ flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center", marginTop: 22 }}>
          <Ionicons name="lock-closed-outline" size={14} color={COLORS.muted} />
          <Text style={{ color: COLORS.muted, fontSize: 12 }}>سجل محلي، دون سحابة</Text>
          {isSaving ? <ActivityIndicator size="small" color={COLORS.olive} /> : null}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
