import { Tabs } from "expo-router";

import { COLORS } from "@/components/wasla-ui";

export default function TabLayout() {
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: COLORS.olive, tabBarInactiveTintColor: COLORS.muted, tabBarStyle: { display: "none" } }}>
      <Tabs.Screen name="index" options={{ title: "الرئيسية" }} />
    </Tabs>
  );
}
