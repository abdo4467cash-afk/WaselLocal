import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Alert, ScrollView, Text, TouchableOpacity, View } from "react-native";

import { BubbleMark, COLORS, IconButton, Surface } from "@/components/wasla-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useWasla } from "@/hooks/use-wasla";

export default function SettingsScreen() {
  const router = useRouter();
  const { state } = useWasla();
  return (
    <ScreenContainer safeAreaClassName="bg-[#F7F5EF]">
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 30 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}><View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}><IconButton name="arrow-forward" label="رجوع" onPress={() => router.back()} /><Text style={{ color: COLORS.ink, fontSize: 22, fontWeight: "900" }}>الإعدادات</Text></View><BubbleMark size={40} /></View>
        <Surface style={{ padding: 16, marginTop: 24 }}><View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}><View style={{ width: 44, height: 44, borderRadius: 16, backgroundColor: COLORS.oliveSoft, alignItems: "center", justifyContent: "center" }}><Ionicons name="person-outline" size={20} color={COLORS.olive} /></View><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontSize: 16, fontWeight: "800", textAlign: "right" }}>{state.profile?.name ?? "—"}</Text><Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 4, textAlign: "right" }}>هوية محلية على هذا الجهاز</Text></View></View></Surface>
        <Text style={{ color: COLORS.ink, fontSize: 17, fontWeight: "900", textAlign: "right", marginTop: 30, marginBottom: 12 }}>الخصوصية والاتصال</Text>
        <Surface>
          <SettingRow icon="cloud-offline-outline" title="لا توجد سحابة" body="لا تُرفع المحادثات أو الملفات إلى خادم مركزي." />
          <SettingRow icon="lock-closed-outline" title="النقل غير متاح في المعاينة" body="لن نعرض تشفيرًا طرفيًا أو اتصالًا مؤكدًا قبل تركيب وحدة Native والتحقق منها." />
          <SettingRow icon="notifications-outline" title="الإشعارات" body="تعمل للرسائل المحلية الحقيقية ضمن قيود Android، ولا تستمر بعد الإيقاف الإجباري." last />
        </Surface>
        <Text style={{ color: COLORS.ink, fontSize: 17, fontWeight: "900", textAlign: "right", marginTop: 30, marginBottom: 12 }}>حول وصلة</Text>
        <Surface style={{ padding: 16 }}><Text style={{ color: COLORS.muted, fontSize: 13, lineHeight: 21, textAlign: "right" }}>وصلة تطبيق محادثة قريب، بلا حسابات وبلا تتبع. البحث الحقيقي يتطلب Android build يضم وحدة البلوتوث والشبكة المحلية؛ المعاينة الحالية لا تستبدل ذلك بمحاكاة.</Text><TouchableOpacity onPress={() => Alert.alert("حالة البناء", "النسخة الحالية جاهزة للمعاينة المصدرية. إنشاء APK Android أصلي يحتاج بيئة Build أصلية خارج Sandbox.")} activeOpacity={0.7} style={{ marginTop: 15, flexDirection: "row-reverse", alignItems: "center", gap: 6 }}><Ionicons name="information-circle-outline" size={16} color={COLORS.olive} /><Text style={{ color: COLORS.olive, fontSize: 13, fontWeight: "800" }}>عرض حدود البناء</Text></TouchableOpacity></Surface>
      </ScrollView>
    </ScreenContainer>
  );
}

function SettingRow({ icon, title, body, last = false }: { icon: keyof typeof Ionicons.glyphMap; title: string; body: string; last?: boolean }) {
  return <View style={{ padding: 15, borderBottomWidth: last ? 0 : 1, borderBottomColor: COLORS.line, flexDirection: "row-reverse", gap: 11, alignItems: "flex-start" }}><Ionicons name={icon} size={20} color={COLORS.olive} style={{ marginTop: 2 }} /><View style={{ flex: 1 }}><Text style={{ color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right" }}>{title}</Text><Text style={{ color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 4, textAlign: "right" }}>{body}</Text></View></View>;
}
