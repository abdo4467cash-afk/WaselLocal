import AsyncStorage from "@react-native-async-storage/async-storage";

export type MessageKind = "text" | "image" | "file" | "audio";
export type MessageStatus = "queued" | "sent" | "delivered" | "failed";

export type Attachment = {
  uri: string;
  name: string;
  mimeType?: string;
  size?: number;
};

export type LocalProfile = {
  id: string;
  name: string;
  createdAt: number;
};

export type NearbyDevice = {
  id: string;
  name: string;
  transport: "bluetooth" | "lan";
  verified: boolean;
  connected: boolean;
};

export type LocalMessage = {
  id: string;
  threadId: string;
  senderId: string;
  senderName: string;
  kind: MessageKind;
  text?: string;
  attachment?: Attachment;
  createdAt: number;
  status: MessageStatus;
  localOnly?: boolean;
};

export type Conversation = {
  id: string;
  kind: "direct" | "group";
  title: string;
  participantIds: string[];
  lastMessageId?: string;
  updatedAt: number;
};

export type LocalGroup = {
  id: string;
  title: string;
  memberIds: string[];
  ownerId: string;
  createdAt: number;
};

export type WaslaState = {
  profile: LocalProfile | null;
  conversations: Conversation[];
  messages: LocalMessage[];
  groups: LocalGroup[];
};

const STORAGE_KEY = "@wasla/state/v1";

export const EMPTY_STATE: WaslaState = {
  profile: null,
  conversations: [],
  messages: [],
  groups: [],
};

function normalizeState(value: unknown): WaslaState {
  if (!value || typeof value !== "object") return EMPTY_STATE;
  const candidate = value as Partial<WaslaState>;
  return {
    profile: candidate.profile ?? null,
    conversations: Array.isArray(candidate.conversations) ? candidate.conversations : [],
    messages: Array.isArray(candidate.messages) ? candidate.messages : [],
    groups: Array.isArray(candidate.groups) ? candidate.groups : [],
  };
}

export async function loadWaslaState(): Promise<WaslaState> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    return raw ? normalizeState(JSON.parse(raw)) : EMPTY_STATE;
  } catch {
    return EMPTY_STATE;
  }
}

export async function saveWaslaState(state: WaslaState): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function formatTime(timestamp?: number): string {
  if (!timestamp) return "";
  return new Intl.DateTimeFormat("ar", { hour: "numeric", minute: "2-digit" }).format(timestamp);
}

export function getConversationPreview(conversation: Conversation, messages: LocalMessage[]): string {
  const message = messages.find((item) => item.id === conversation.lastMessageId);
  if (!message) return "لم تبدأ المحادثة بعد";
  if (message.kind === "image") return "صورة";
  if (message.kind === "file") return message.attachment?.name ?? "ملف";
  if (message.kind === "audio") return "رسالة صوتية";
  return message.text ?? "رسالة";
}
