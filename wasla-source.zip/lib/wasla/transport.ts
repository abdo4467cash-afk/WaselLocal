import { NativeModules, Platform } from "react-native";

export type TransportMode = "bluetooth" | "lan";
export type TransportState = "idle" | "searching" | "ready" | "unavailable" | "error";

export type TransportSnapshot = {
  state: TransportState;
  mode: TransportMode;
  detail: string;
  nativeBridge: boolean;
};

export type TransportResult = {
  ok: boolean;
  snapshot: TransportSnapshot;
};

type NativeTransportBridge = {
  startDiscovery?: (mode: TransportMode) => Promise<unknown>;
  requestBluetoothEnable?: () => Promise<boolean>;
};

const nativeBridge = NativeModules.WaslaLocalTransport as NativeTransportBridge | undefined;

const previewSnapshot: TransportSnapshot = {
  state: "unavailable",
  mode: "bluetooth",
  detail: "المعاينة لا تتضمن جسر Android للبلوتوث أو الشبكة المحلية.",
  nativeBridge: false,
};

export function getInitialTransportSnapshot(): TransportSnapshot {
  return Platform.OS === "web"
    ? previewSnapshot
    : {
        state: nativeBridge ? "idle" : "unavailable",
        mode: "bluetooth",
        detail: nativeBridge
          ? "جسر Android متاح، بانتظار بدء البحث."
          : "يلزم Native build يضم وحدة النقل المحلي قبل بدء الاكتشاف.",
        nativeBridge: Boolean(nativeBridge),
      };
}

/**
 * This is intentionally not a simulator. A device is only reported by a
 * Native transport module that has actually discovered the app protocol.
 */
export async function startDiscovery(mode: TransportMode = "bluetooth"): Promise<TransportResult> {
  if (!nativeBridge?.startDiscovery) {
    return {
      ok: false,
      snapshot: {
        ...getInitialTransportSnapshot(),
        state: "unavailable",
        mode,
        detail:
          Platform.OS === "web"
            ? "البحث الحقيقي يحتاج تشغيل Android أصليًا؛ لم نعرض أجهزة وهمية."
            : "لم تُضمّن وحدة Native للنقل في هذا البناء؛ لم نعرض أجهزة وهمية.",
      },
    };
  }

  try {
    await nativeBridge.startDiscovery(mode);
    return {
      ok: true,
      snapshot: {
        state: "searching",
        mode,
        detail: mode === "bluetooth" ? "جارٍ البحث عبر البلوتوث…" : "جارٍ البحث على الشبكة المحلية…",
        nativeBridge: true,
      },
    };
  } catch {
    return {
      ok: false,
      snapshot: {
        state: "error",
        mode,
        detail: "تعذر بدء البحث. تحقق من الأذونات واتصال الجهاز.",
        nativeBridge: true,
      },
    };
  }
}

export async function requestBluetoothEnable(): Promise<boolean> {
  if (!nativeBridge?.requestBluetoothEnable) return false;
  try {
    return await nativeBridge.requestBluetoothEnable();
  } catch {
    return false;
  }
}
