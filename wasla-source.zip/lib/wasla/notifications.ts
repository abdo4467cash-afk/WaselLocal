import { Platform } from "react-native";
import * as Notifications from "expo-notifications";

const CHANNEL_ID = "wasla-messages";
const notifiedIds = new Set<string>();

export async function configureNotifications(): Promise<void> {
  if (Platform.OS === "web") return;
  await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
    name: "رسائل وصلة",
    importance: Notifications.AndroidImportance.DEFAULT,
    vibrationPattern: [0, 120],
    lightColor: "#66704B",
  });
  await Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: false,
      shouldSetBadge: true,
    }),
  });
}

export async function notifyIncomingMessage(input: {
  id: string;
  senderName: string;
  conversationTitle?: string;
  preview: string;
}): Promise<void> {
  if (Platform.OS === "web" || notifiedIds.has(input.id)) return;
  notifiedIds.add(input.id);
  await Notifications.scheduleNotificationAsync({
    content: {
      title: input.conversationTitle ? `${input.senderName} · ${input.conversationTitle}` : input.senderName,
      body: input.preview,
      data: { messageId: input.id, threadId: input.conversationTitle },
    },
    trigger: null,
  });
}
