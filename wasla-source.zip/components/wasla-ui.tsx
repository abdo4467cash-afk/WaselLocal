import { Ionicons } from "@expo/vector-icons";
import type { ComponentProps } from "react";
import { Text, TouchableOpacity, View } from "react-native";

export const COLORS = {
  canvas: "#F7F5EF",
  paper: "#FFFDF8",
  ink: "#252822",
  muted: "#74796C",
  line: "#E6E4DA",
  olive: "#66704B",
  oliveSoft: "#E6EBDD",
  olivePale: "#F1F3EA",
  amber: "#B27A38",
  danger: "#B85A50",
  white: "#FFFFFF",
};

type IconName = ComponentProps<typeof Ionicons>["name"];

export function BubbleMark({ size = 46 }: { size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.3, backgroundColor: COLORS.olive, alignItems: "center", justifyContent: "center" }}>
      <Ionicons name="chatbubble-ellipses-outline" size={size * 0.52} color={COLORS.white} />
    </View>
  );
}

export function IconButton({ name, onPress, label, filled = false }: { name: IconName; onPress: () => void; label?: string; filled?: boolean }) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      activeOpacity={0.72}
      style={{ width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: filled ? COLORS.olive : COLORS.paper, borderWidth: filled ? 0 : 1, borderColor: COLORS.line }}
    >
      <Ionicons name={name} size={20} color={filled ? COLORS.white : COLORS.ink} />
    </TouchableOpacity>
  );
}

export function StatusPill({ tone, children }: { tone: "ok" | "quiet" | "warn"; children: string }) {
  const palette = tone === "ok" ? { bg: COLORS.oliveSoft, fg: COLORS.olive, icon: "radio-button-on" as const } : tone === "warn" ? { bg: "#F7EBDD", fg: COLORS.amber, icon: "alert-circle-outline" as const } : { bg: "#EFEEE8", fg: COLORS.muted, icon: "ellipse-outline" as const };
  return (
    <View style={{ alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: palette.bg, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 999 }}>
      <Ionicons name={palette.icon} size={12} color={palette.fg} />
      <Text style={{ color: palette.fg, fontSize: 12, fontWeight: "700" }}>{children}</Text>
    </View>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
      <Text style={{ color: COLORS.ink, fontSize: 17, fontWeight: "800" }}>{title}</Text>
      {action && onAction ? (
        <TouchableOpacity onPress={onAction} activeOpacity={0.7}>
          <Text style={{ color: COLORS.olive, fontSize: 13, fontWeight: "700" }}>{action}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export function Surface({ children, style }: { children: React.ReactNode; style?: object }) {
  return <View style={[{ backgroundColor: COLORS.paper, borderRadius: 22, borderWidth: 1, borderColor: COLORS.line }, style]}>{children}</View>;
}

export function EmptyState({ icon, title, body }: { icon: IconName; title: string; body: string }) {
  return (
    <View style={{ alignItems: "center", paddingVertical: 24, paddingHorizontal: 18 }}>
      <View style={{ width: 52, height: 52, borderRadius: 18, backgroundColor: COLORS.olivePale, alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
        <Ionicons name={icon} size={24} color={COLORS.olive} />
      </View>
      <Text style={{ color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "center" }}>{title}</Text>
      <Text style={{ color: COLORS.muted, fontSize: 13, lineHeight: 20, textAlign: "center", marginTop: 6 }}>{body}</Text>
    </View>
  );
}
