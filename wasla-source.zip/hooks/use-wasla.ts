import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
  EMPTY_STATE,
  type Attachment,
  type Conversation,
  type LocalGroup,
  type LocalMessage,
  type WaslaState,
  loadWaslaState,
  makeId,
  saveWaslaState,
} from "@/lib/wasla/store";
import { configureNotifications } from "@/lib/wasla/notifications";
import { getInitialTransportSnapshot, startDiscovery, type TransportMode, type TransportSnapshot } from "@/lib/wasla/transport";

export function useWasla() {
  const [state, setState] = useState<WaslaState | null>(null);
  const [transport, setTransport] = useState<TransportSnapshot>(getInitialTransportSnapshot);
  const [isSaving, setIsSaving] = useState(false);
  const saveQueue = useRef(Promise.resolve());

  useEffect(() => {
    void loadWaslaState().then(setState);
    void configureNotifications();
  }, []);

  const persist = useCallback((next: WaslaState) => {
    setState(next);
    setIsSaving(true);
    saveQueue.current = saveQueue.current
      .catch(() => undefined)
      .then(() => saveWaslaState(next))
      .finally(() => setIsSaving(false));
  }, []);

  const setProfileName = useCallback(
    (name: string) => {
      if (!state) return;
      persist({
        ...state,
        profile: { id: makeId("me"), name: name.trim(), createdAt: Date.now() },
      });
    },
    [persist, state],
  );

  const discover = useCallback(async (mode: TransportMode = "bluetooth") => {
    setTransport((current) => ({ ...current, state: "searching", mode, detail: "جارٍ تهيئة الاتصال…" }));
    const result = await startDiscovery(mode);
    setTransport(result.snapshot);
    return result;
  }, []);

  const addMessage = useCallback(
    (input: { threadId: string; kind: LocalMessage["kind"]; text?: string; attachment?: Attachment }) => {
      if (!state?.profile) return;
      const message: LocalMessage = {
        id: makeId("message"),
        threadId: input.threadId,
        senderId: state.profile.id,
        senderName: state.profile.name,
        kind: input.kind,
        text: input.text,
        attachment: input.attachment,
        createdAt: Date.now(),
        status: "queued",
        localOnly: true,
      };
      const existing = state.conversations.find((item) => item.id === input.threadId);
      const conversation: Conversation = existing ?? {
        id: input.threadId,
        kind: "direct",
        title: "محادثة محلية",
        participantIds: [],
        updatedAt: message.createdAt,
      };
      persist({
        ...state,
        messages: [...state.messages, message],
        conversations: [
          ...state.conversations.filter((item) => item.id !== input.threadId),
          { ...conversation, lastMessageId: message.id, updatedAt: message.createdAt },
        ],
      });
      return message;
    },
    [persist, state],
  );

  const addGroup = useCallback(
    (title: string, memberIds: string[]): LocalGroup | undefined => {
      if (!state?.profile) return undefined;
      const group: LocalGroup = {
        id: makeId("group"),
        title: title.trim(),
        memberIds,
        ownerId: state.profile.id,
        createdAt: Date.now(),
      };
      const conversation: Conversation = {
        id: group.id,
        kind: "group",
        title: group.title,
        participantIds: memberIds,
        updatedAt: group.createdAt,
      };
      persist({ ...state, groups: [...state.groups, group], conversations: [...state.conversations, conversation] });
      return group;
    },
    [persist, state],
  );

  const messagesFor = useCallback(
    (threadId: string) => (state?.messages ?? []).filter((message) => message.threadId === threadId),
    [state?.messages],
  );

  return useMemo(
    () => ({ state: state ?? EMPTY_STATE, hydrated: state !== null, transport, isSaving, setProfileName, discover, addMessage, addGroup, messagesFor }),
    [addGroup, addMessage, discover, isSaving, messagesFor, setProfileName, state, transport],
  );
}
