# بناء APK من الهاتف

أسهل طريقة لهذا المشروع هي استخدام Termux لتنفيذ أوامر Expo، ثم استخدام EAS Build السحابي لإنتاج APK. لا تستخدم CodeOnTheGo لهذا المشروع لأنه مبني بـ Expo/React Native وليس مشروع Kotlin/Gradle أصليًا.

## 1. تثبيت الأدوات

ثبّت Termux من مصدره الرسمي أو من F-Droid، ثم افتحه ونفّذ:

```bash
pkg update -y && pkg upgrade -y
pkg install nodejs-lts git unzip -y
npm install -g pnpm eas-cli
termux-setup-storage
```

وافق على إذن الملفات عندما يطلبه Termux.

## 2. تجهيز المصدر

نزّل `wasla-source.zip` إلى مجلد Downloads في الهاتف، ثم نفّذ:

```bash
cd ~/storage/downloads
unzip -o wasla-source.zip -d wasla
cd wasla
pnpm install
```

إذا أنشأ فك الضغط مجلدًا داخليًا إضافيًا، ادخل إلى المجلد الذي يحتوي `package.json` و`app.config.ts` قبل تنفيذ `pnpm install`.

## 3. تسجيل الدخول والبناء

أنشئ حساب Expo مجانيًا من المتصفح، ثم نفّذ:

```bash
eas login
eas build --platform android --profile preview
```

عند سؤال EAS عن إنشاء مفاتيح Android، اختر إنشاءها تلقائيًا. انتظر انتهاء البناء، ثم افتح رابط APK الذي سيظهر في الطرفية. يمكن أيضًا فتح صفحة المشروع في Expo Dashboard وتنزيل ملف APK من تفاصيل البناء.

## 4. تثبيت APK

افتح رابط APK على الهاتف، فعّل السماح بالتثبيت من هذا المصدر عند طلب Android، ثم ثبّت التطبيق.

## ملاحظات مهمة

هذا المسار يبني APK قابلًا للتثبيت من المصدر الحالي، لكنه لا يضيف وحده وحدة Bluetooth/Wi‑Fi الأصلية. النسخة الحالية تعرض الواجهة والتخزين المحلي والمرفقات المحلية، وتتعمد عدم عرض أجهزة وهمية. الاتصال الحقيقي بين جهازين يحتاج تنفيذ Native transport module أولًا، ثم إعادة تشغيل أمر EAS نفسه.

لإنشاء نسخة متجر Google Play استخدم:

```bash
eas build --platform android --profile production
```

هذا ينتج AAB وليس APK، وهو المسار المعتاد للنشر في Google Play.
